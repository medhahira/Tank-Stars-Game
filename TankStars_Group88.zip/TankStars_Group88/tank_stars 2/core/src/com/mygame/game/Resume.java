package com.mygame.game;
import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.utils.ScreenUtils;
import com.badlogic.gdx.math.Vector3;

import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.BitmapFont.*;
public class Resume extends ApplicationAdapter implements Screen {

    private BitmapFont font;
    private SpriteBatch batch = new SpriteBatch();
    private Texture resumeTexture;
    private Sprite resumeSprite;
    Vector3 temp = new Vector3();
    public static MainGame game;
    private static float RESUME_VERTICAL_PF = 3.0f;

    public Resume(MainGame game){
        Resume.game = game;
        batch = new SpriteBatch();
        font = new BitmapFont(Gdx.files.internal("data/ken.fnt"));

        //BitmapFont.TextBounds bounds = font.getBounds("Hello World");

        float height= Gdx.graphics.getHeight();
        float width = Gdx.graphics.getWidth();
        resumeTexture = new Texture("data/resume_screen.png");
        resumeSprite = new Sprite(resumeTexture);
        resumeSprite.setSize(width, height);
        resumeSprite.setPosition(0,0);
    }
    @Override
    public void create () {

    }
    @Override
    public void show() {

    }

    @Override
    public void render(float delta) {
        Gdx.gl.glClearColor(26/255f, 41/255f, 106/255f, 1);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
        batch.begin();
        resumeSprite.draw(batch);
        batch.end();
        //batch.begin();
        //BitmapFont.Glyph bounds = font.getData().getFirstGlyph();
        //font.draw(batch, "welcome player 1", Gdx.graphics.getWidth()/2, Gdx.graphics.getHeight()/2);
        //font.draw(batch, "welcome player 1", Gdx.graphics.getWidth()/2 - bounds.width/2, Gdx.graphics.getHeight()/2+bounds.height/2);
        //font.draw(batch,"WELCOME PLAYER 1", Gdx.graphics.getWidth()/2 - (bounds.width), Gdx.graphics.getHeight()/2 + (bounds.height));
        //font.getData().setScale(Gdx.graphics.getWidth()/1400f);
        //resumeSprite.draw(batch);
        //font.draw(batch,"Hello World",Gdx.graphics.getWidth()/2,Gdx.graphics.getHeight()/2);
        //batch.end();
    }

    @Override
    public void resize(int width, int height) {

    }

    @Override
    public void pause() {

    }

    @Override
    public void resume() {

    }

    @Override
    public void hide() {

    }

    @Override
    public void dispose() {
        batch.dispose();
        resumeTexture.dispose();
    }

    public SpriteBatch getBatch() {
        return batch;
    }

    public void setBatch(SpriteBatch batch) {
        this.batch = batch;
    }
}
